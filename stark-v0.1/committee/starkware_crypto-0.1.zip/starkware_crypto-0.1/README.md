# StarkWare Crypto

**A cryptographic library for the Stark Exchange**
