# Stark Storage

**A storage abstraction library**
