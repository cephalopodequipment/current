# Mock Availability Gateway Service

**A Mock of the Gateway Service Providing availability data for Committee members**
